﻿namespace ExcelDataReader.Core.NumberFormat
{
    internal class Condition
    {
        public string Operator { get; set; }

        public double Value { get; set; }
    }
}
